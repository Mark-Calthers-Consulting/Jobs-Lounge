module.exports=[27096,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28admin%29_admin-center_%28dashboard%29_candidates_page_actions_0p1in-i.js.map