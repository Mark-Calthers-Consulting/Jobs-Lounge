module.exports=[77628,(a,b,c)=>{}];

//# sourceMappingURL=0ivl_%28admin%29_admin-center_%28dashboard%29_applications_by-vacancy_page_actions_0ndxka9.js.map