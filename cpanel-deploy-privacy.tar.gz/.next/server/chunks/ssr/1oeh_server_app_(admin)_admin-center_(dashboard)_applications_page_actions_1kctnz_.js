module.exports=[52068,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28admin%29_admin-center_%28dashboard%29_applications_page_actions_1kctnz_.js.map