module.exports=[38163,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%28admin%29_admin-center_%28dashboard%29_jobs_%5BjobId%5D_edit_page_actions_05pqjn_.js.map