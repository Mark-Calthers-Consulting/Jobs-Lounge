module.exports=[78896,(a,b,c)=>{}];

//# sourceMappingURL=0ivl_%28admin%29_admin-center_%28dashboard%29_settings_change-password_page_actions_1hmlaqq.js.map