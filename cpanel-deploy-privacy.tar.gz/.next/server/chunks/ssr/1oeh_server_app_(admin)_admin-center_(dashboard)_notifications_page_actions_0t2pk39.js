module.exports=[57610,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28admin%29_admin-center_%28dashboard%29_notifications_page_actions_0t2pk39.js.map