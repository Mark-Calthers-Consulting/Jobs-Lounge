module.exports=[35129,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28admin%29_admin-center_%28dashboard%29_announcements_page_actions_123vsy4.js.map