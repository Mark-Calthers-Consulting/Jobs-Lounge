module.exports=[29817,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%28admin%29_admin-center_%28dashboard%29_applications_inbox_page_actions_0rowo5l.js.map