module.exports=[17792,a=>{"use strict";var b=a.i(7997),c=a.i(80549);a.s(["default",0,()=>(0,b.jsx)("div",{className:"flex min-h-[65vh] items-center bg-[#F8FAFC]",children:(0,b.jsx)(c.default,{})})])},85430,a=>{a.n(a.i(17792))}];

//# sourceMappingURL=app_%28public%29_%28main%29_not-found_tsx_05t11y_._.js.map