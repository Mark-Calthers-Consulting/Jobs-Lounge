1:"$Sreact.fragment"
2:I[9291,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js","/_next/static/chunks/2213t4-15tqch.js","/_next/static/chunks/3p6-f5lj_ycn_.js","/_next/static/chunks/052rrygbgc42e.js","/_next/static/chunks/01rqxq16ulumi.js","/_next/static/chunks/29ato6iy69o8d.js"],"default"]
3:I[97367,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/052rrygbgc42e.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/01rqxq16ulumi.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/29ato6iy69o8d.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"CR9KykzWE6gdEAICL5KDD"}
5:null
