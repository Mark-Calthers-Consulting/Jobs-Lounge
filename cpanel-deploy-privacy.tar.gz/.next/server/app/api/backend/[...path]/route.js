var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/backend/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1iuyvx-._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_backend_[___path]_route_actions_0xgsz5t.js")
R.m(64305)
module.exports=R.m(64305).exports
