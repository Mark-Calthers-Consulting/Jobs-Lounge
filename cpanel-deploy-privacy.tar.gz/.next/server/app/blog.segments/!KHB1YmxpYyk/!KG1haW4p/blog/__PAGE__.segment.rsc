1:"$Sreact.fragment"
2:I[9789,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js","/_next/static/chunks/1xbo_3lu1d2sc.js","/_next/static/chunks/28zw1ocdp0pg1.js","/_next/static/chunks/29ato6iy69o8d.js","/_next/static/chunks/455sa3749-8vj.js"],"default"]
3:I[97367,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/455sa3749-8vj.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"CR9KykzWE6gdEAICL5KDD"}
5:null
