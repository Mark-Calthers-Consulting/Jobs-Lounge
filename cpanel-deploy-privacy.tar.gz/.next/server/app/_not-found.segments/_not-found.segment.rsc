1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js"],"default"]
3:I[37457,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"CR9KykzWE6gdEAICL5KDD"}
