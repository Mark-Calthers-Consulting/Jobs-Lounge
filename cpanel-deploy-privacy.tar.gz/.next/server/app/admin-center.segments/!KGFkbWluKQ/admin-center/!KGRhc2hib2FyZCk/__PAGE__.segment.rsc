1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[45332,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js","/_next/static/chunks/33nkq1k1ink26.js","/_next/static/chunks/3p6-f5lj_ycn_.js","/_next/static/chunks/28zw1ocdp0pg1.js","/_next/static/chunks/3cuz--_rva0wt.js","/_next/static/chunks/3ye0jwilo0d9y.js"],"default"]
4:I[97367,["/_next/static/chunks/13yov70156ycx.js","/_next/static/chunks/2im7c515bo69p.js","/_next/static/chunks/40gishkd8zoe4.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":null,"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/3ye0jwilo0d9y.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"CR9KykzWE6gdEAICL5KDD"}
5:null
